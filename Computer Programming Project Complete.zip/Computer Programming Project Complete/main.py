from phoneme import phoneme_all
import os
from pathlib import Path

#this line asks the user to insert the path of the files
amharic_input_path = input("Enter your Amharic document path: ")
tigrigna_input_path = input("Enter your Tigrigna document path: ")

#this line accepts the path of the files
amharic_input = open(amharic_input_path, encoding='utf8').read()
tigrigna_input = open(tigrigna_input_path, encoding='utf8').read()


#this function counts the frequency of the words accepted from both of the inputs
def word_frequency_counter(splitted_input):
    word_splitter(splitted_input)
    frequency_dictionary = dict()
    known_words = set()
    for frequency in word_splitter(splitted_input):
        if frequency in known_words:
            frequency_dictionary[frequency] += 1
        else:
            frequency_dictionary[frequency] = 1
            known_words.add(frequency)
    return frequency_dictionary


#this function splits each words accepted from the user file
def word_splitter(language_input):
    punctuation_remover(language_input)
    splitted_input = language_input.split()
    return splitted_input


#this function removes the punctuation included in the text for better word processing
def punctuation_remover(language_input):
    punctuation_list = [".", '፣', '.', '፡', '፦', '፥', '፤', '. . .', '“', '‘', '!', '፧', '/', '<<', '>>', '-', '—', '=',
                        '*', '"', '።']
    for checker in punctuation_list:
        language_input = language_input.replace(checker, " ")
    return language_input

#calling the frequency counter function
tigrigna_frequency = word_frequency_counter(tigrigna_input)
amharic_frequency = word_frequency_counter(amharic_input)

#differentiating words as tigrigna only, amharic only and common
tigrigna_only = []
amharic_only = []
common = []

# it appends words that is only found in tigrigna language to tigrigna_only list
for word in tigrigna_frequency:
    if word in amharic_frequency:
        common.append(word)
    else:
        tigrigna_only.append(word)

# it appends the words that is not found in tigrigna language to amharic_only list
for word in amharic_frequency:
    if word not in tigrigna_frequency:
        amharic_only.append(word)

#this line calculates the ratio of common words to words that is found in one of the languages.
amharic_to_tigrigna_percentage = (len(common) / len(amharic_frequency)) * 100
tigrigna_to_amharic_percentage = (len(common) / len(tigrigna_frequency)) * 100


#it converts the text written in amharic text to international phonemic notation
def phoneme_converter(text):
    phonetic_text = []
    for char in text:
        phonetic_char = phoneme_all.get(char, char)  # Use the original char if no mapping is found
        phonetic_text.append(phonetic_char)
    return ''.join(phonetic_text)

# here is the list of the consonants and vowels
phoneme_consonant= ['h','l','ħ','m','ś','r','s','ʃ','kʼ','b','v','t','ʧ','ḫ','n','ɲ','ʾ','k','x','w','ʕ','z','ʒ','y','d','ʤ','g','ŋ','tʼ','ʧʼ','pʼ','sʼ','ṣ́','f','p','ʁʼ']
phoneme_vowel= ['ə','u','i','a','e','ɨ','o']

phoneme_amharic = phoneme_converter(punctuation_remover(amharic_input))
phoneme_tigrigna = phoneme_converter(punctuation_remover(tigrigna_input))


def phoneme_frequency(phoneme):
    phonemic_frequency = dict()
    for i in phoneme:
        if i in (phoneme_consonant or phoneme_vowel):
            if i not in phonemic_frequency:
                count = 1
                phonemic_frequency[i] = count
            else:
                phonemic_frequency[i] += 1
    return phonemic_frequency


phonemic_frquency_of_tigrigna = phoneme_frequency(phoneme_tigrigna)
phonemic_frquency_of_amharic = phoneme_frequency(phoneme_amharic)
tigrigna_vowel = set()
amharic_vowel = set()
common_vowel = set()
amharic_conosonant = set()
tigrigna_consonant = set()
common_consonant =  set()
for vowel_or_consonant in phoneme_tigrigna:
    if vowel_or_consonant in phoneme_vowel and vowel_or_consonant in phoneme_amharic:
        common_vowel.add(vowel_or_consonant)
    elif vowel_or_consonant in phoneme_vowel:
        tigrigna_vowel.add(vowel_or_consonant)
    elif vowel_or_consonant in phoneme_amharic and vowel_or_consonant in phoneme_consonant:
        common_consonant.add(vowel_or_consonant)
    elif vowel_or_consonant in phoneme_consonant:
        tigrigna_consonant.add(vowel_or_consonant)
for vowel_or_consonant_2 in phoneme_amharic:
    if vowel_or_consonant_2 in phoneme_vowel and vowel_or_consonant_2 not in phoneme_tigrigna:
        amharic_vowel.add(vowel_or_consonant_2)
    elif vowel_or_consonant_2 not in phoneme_tigrigna and vowel_or_consonant_2 in phoneme_consonant:
        amharic_conosonant.add(vowel_or_consonant_2)


with open(f"output_{Path(amharic_input_path).stem}_to_{Path(tigrigna_input_path).stem}.txt",'w',encoding='utf-8') as op:
    op.write("word frequency of Tigrigna:-\n")
    op.write(f'{tigrigna_frequency}\n')
    op.write('word frequency of Amharic:-\n')
    op.write(f'{amharic_frequency}\n')
    op.write('the word found only in tigrgna language:-\n')
    op.write(f'{tigrigna_only} are found only in tigrgna language\n')
    op.write('the word found only in amharic language:-\n')
    op.write(f'{amharic_only} are found only in amharic language\n')
    op.write('the word found in both tigrgna and amharic language:-\n')
    op.write(f'{common} are found in both ትግርኛ and አማርኛ language which means {tigrigna_to_amharic_percentage}% of Tigrgna language or {amharic_to_tigrigna_percentage}% of Amharic language is overlap to each other.\n')
    op.write(f'The phoneme of ትግርኛ text is:\n{phoneme_tigrigna}\n')
    op.write(f'The phoneme of አማርኛ text is:\n{phoneme_amharic}\n')
    op.write('phonemic frequency of ትግርኛ:-\n')
    op.write(f'{phonemic_frquency_of_tigrigna}\n')
    op.write('phonemic frequency of አማርኛ:-\n')
    op.write(f'{phonemic_frquency_of_amharic}\n')
    op.write(f'The phonemic vowel found only in ትግርኛ text:{tigrigna_vowel}\n')
    op.write(f'The phonemic vowel found only in አማርኛ text:{amharic_vowel}\n')
    op.write(f'The phonemic consonant found only in ትግርኛ text:{tigrigna_consonant}\n')
    op.write(f'The phonemic consonant found only in አማርኛ text:{amharic_conosonant}\n')
    op.write(f'The phonemic vowel found in both አማርኛ and ትግርኛ text:{common_vowel}\n')
    op.write(f'The phonemic consonant found in both አማርኛ and ትግርኛ text:{common_consonant}\n')
    op.write(f'this means {len(common_consonant)/(len(tigrigna_consonant)+len(common_consonant))*100}% of consonant in ትግርኛ language or {len(common_consonant)/(len(amharic_conosonant)+len(common_consonant))*100}% of consonant in አማርኛ language is overlap to each other.\n')
    op.write(f'this means {len(common_vowel)/(len(tigrigna_vowel)+len(common_vowel))*100}% of phonemic vowel in ትግርኛ language or {len(common_vowel)/(len(amharic_vowel)+len(common_vowel))*100}% of phonemic vowel in አማርኛ language is overlap to each other.\n')
    op.close()

pathOfReport = os.path.abspath(f"output_{Path(amharic_input_path).stem}_to_{Path(tigrigna_input_path).stem}.txt")
print(f'The report file is exported to {pathOfReport}')
